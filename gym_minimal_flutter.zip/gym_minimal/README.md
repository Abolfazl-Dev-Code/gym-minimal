# Gym Minimal (Flutter)
A minimal, offline Persian workout logger prototype.

## Included
- Workout days and exercise templates (edit/add/delete)
- Exercise set/reps template
- In-session weight and rep logging
- Local history
- Local persistence via SharedPreferences

## Run
```sh
flutter pub get
flutter run
```

This source was prepared in an environment without Flutter/Dart SDK, so it has not been compiled here. Please run `flutter analyze` and `flutter test` locally before use.
