import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const GymApp());

const accent = Color(0xFFB7F36B);
const bg = Color(0xFF101211);
const panel = Color(0xFF1B1F1D);

class GymApp extends StatelessWidget {
  const GymApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: accent, secondary: accent, surface: panel),
      cardColor: panel,
      textTheme: ThemeData.dark().textTheme.apply(fontFamily: 'Roboto'),
    ),
    home: const HomePage(),
  );
}


class Exercise {
  String name;
  int sets;
  int reps;
  Exercise(this.name, this.sets, this.reps);
  Map<String, dynamic> toJson() => {'name': name, 'sets': sets, 'reps': reps};
  factory Exercise.fromJson(Map<String, dynamic> j) => Exercise(j['name'] ?? '', j['sets'] ?? 3, j['reps'] ?? 10);
}


class WorkoutDay {
  String name;
  List<Exercise> exercises;
  WorkoutDay(this.name, this.exercises);
  Map<String, dynamic> toJson() => {'name': name, 'exercises': exercises.map((e) => e.toJson()).toList()};
  factory WorkoutDay.fromJson(Map<String, dynamic> j) => WorkoutDay(j['name'] ?? 'تمرین', (j['exercises'] as List? ?? []).map((e) => Exercise.fromJson(Map<String, dynamic>.from(e))).toList());
}


class SetEntry {
  int reps;
  double weight;
  SetEntry(this.reps, this.weight);
  Map<String, dynamic> toJson() => {'reps': reps, 'weight': weight};
}


class SessionRecord {
  String day;
  DateTime date;
  Map<String, List<SetEntry>> logs;
  SessionRecord(this.day, this.date, this.logs);
  Map<String, dynamic> toJson() => {'day': day, 'date': date.toIso8601String(), 'logs': logs.map((k,v) => MapEntry(k, v.map((e) => e.toJson()).toList()))};
  factory SessionRecord.fromJson(Map<String, dynamic> j) => SessionRecord(j['day'], DateTime.parse(j['date']), (j['logs'] as Map).map((k,v) => MapEntry(k.toString(), (v as List).map((e) => SetEntry(e['reps'] ?? 0, (e['weight'] as num? ?? 0).toDouble())).toList())));
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}


class _HomePageState extends State<HomePage> {
  int tab = 0;
  int selectedDay = 0;
  List<WorkoutDay> days = [
    WorkoutDay('شنبه', [Exercise('پرس سینه', 3, 10), Exercise('پرس بالا سینه دمبل', 3, 10), Exercise('فلای', 3, 12)]),
    WorkoutDay('دوشنبه', [Exercise('لت سیم‌کش', 3, 10), Exercise('قایقی', 3, 12), Exercise('جلو بازو دمبل', 3, 12)]),
    WorkoutDay('چهارشنبه', [Exercise('اسکوات', 3, 10), Exercise('پرس پا', 3, 12), Exercise('پشت پا', 3, 12)]),
  ];
  List<SessionRecord> history = [];
  bool loaded = false;

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final d = p.getString('days'); final h = p.getString('history');
    if (d != null) days = (jsonDecode(d) as List).map((e) => WorkoutDay.fromJson(Map<String,dynamic>.from(e))).toList();
    if (h != null) history = (jsonDecode(h) as List).map((e) => SessionRecord.fromJson(Map<String,dynamic>.from(e))).toList();
    if (mounted) setState(() => loaded = true);
  }
  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('days', jsonEncode(days.map((e) => e.toJson()).toList()));
    await p.setString('history', jsonEncode(history.map((e) => e.toJson()).toList()));
  }
  String get dateLabel => '${DateTime.now().day.toString().padLeft(2,'0')}.${DateTime.now().month.toString().padLeft(2,'0')}';

  @override
  Widget build(BuildContext context) {
    if (!loaded) return const Scaffold(body: Center(child: CircularProgressIndicator(color: accent)));
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: SafeArea(child: tab == 0 ? _workoutView() : tab == 1 ? _historyView() : _settingsView()),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel, indicatorColor: accent.withValues(alpha: .13), selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [NavigationDestination(icon: Icon(Icons.fitness_center_outlined), selectedIcon: Icon(Icons.fitness_center), label: 'تمرین'), NavigationDestination(icon: Icon(Icons.history), label: 'تاریخچه'), NavigationDestination(icon: Icon(Icons.tune), label: 'تنظیمات')],
      ),
    ));
  }

  Widget _workoutView() => CustomScrollView(slivers: [
    SliverPadding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 10), sliver: SliverToBoxAdapter(child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('GYM LOG', style: TextStyle(color: accent, letterSpacing: 2, fontWeight: FontWeight.w800)), const SizedBox(height: 7), const Text('برنامه تمرینی', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold))]),
      Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14)), child: Text(dateLabel, style: const TextStyle(color: Colors.white70))),
    ]))),
    SliverPadding(padding: const EdgeInsets.fromLTRB(20, 10, 20, 0), sliver: SliverToBoxAdapter(child: Row(children: [const Text('روزهای تمرین', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)), const Spacer(), Text('${days.length} روز', style: const TextStyle(color: Colors.white54)),]))),
    SliverPadding(padding: const EdgeInsets.fromLTRB(20, 12, 20, 12), sliver: SliverToBoxAdapter(child: SizedBox(height: 58, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: days.length + 1, separatorBuilder: (_,__) => const SizedBox(width: 8), itemBuilder: (_,i) {
      if (i == days.length) return InkWell(onTap: _addDay, borderRadius: BorderRadius.circular(16), child: Container(width: 58, decoration: BoxDecoration(border: Border.all(color: Colors.white24), borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.add, color: Colors.white60)));
      final active = i == selectedDay;
      return InkWell(onTap: () => setState(() => selectedDay = i), borderRadius: BorderRadius.circular(16), child: Container(width: 105, alignment: Alignment.center, decoration: BoxDecoration(color: active ? accent : panel, borderRadius: BorderRadius.circular(16)), child: Text(days[i].name, style: TextStyle(color: active ? bg : Colors.white70, fontWeight: FontWeight.bold))));
    })))),
    SliverPadding(padding: const EdgeInsets.fromLTRB(20, 5, 20, 12), sliver: SliverToBoxAdapter(child: Row(children: [Text(days[selectedDay].name, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), const Spacer(), IconButton(onPressed: _editDayName, icon: const Icon(Icons.edit_outlined, size: 19, color: Colors.white54)), IconButton(onPressed: _addExercise, icon: const Icon(Icons.add_circle, color: accent))]))),
    SliverPadding(padding: const EdgeInsets.fromLTRB(20, 0, 20, 12), sliver: SliverToBoxAdapter(child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)), child: Row(children: [Icon(Icons.list_alt, color: accent), const SizedBox(width: 10), Text('${days[selectedDay].exercises.length} حرکت'), const Spacer(), Text('${days[selectedDay].exercises.fold<int>(0,(sum,e)=>sum+e.sets)} ست در کل', style: const TextStyle(color: Colors.white54))]))),
    SliverPadding(padding: const EdgeInsets.symmetric(horizontal: 20), sliver: SliverList(delegate: SliverChildBuilderDelegate((context,i) {
      final e = days[selectedDay].exercises[i];
      return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)), child: Row(children: [Container(width: 42,height: 42,alignment: Alignment.center,decoration: BoxDecoration(color: accent.withValues(alpha:.12),borderRadius: BorderRadius.circular(13)), child: Text('${i+1}',style: const TextStyle(color: accent,fontWeight: FontWeight.bold))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(e.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 5), Text('${e.sets} ست  ·  ${e.reps} تکرار', style: const TextStyle(color: Colors.white54))])), IconButton(onPressed: () => _editExercise(e), icon: const Icon(Icons.more_horiz, color: Colors.white38))]));
    }, childCount: days[selectedDay].exercises.length))),
    SliverPadding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 25), sliver: SliverToBoxAdapter(child: SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: accent, foregroundColor: bg, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), onPressed: _startWorkout, icon: const Icon(Icons.play_arrow), label: const Text('شروع تمرین', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))))),
  ]);


  Widget _historyView() => Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SizedBox(height: 12), const Text('تاریخچه', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), const SizedBox(height: 6), const Text('جلسات ثبت‌شده', style: TextStyle(color: Colors.white54)), const SizedBox(height: 18), Expanded(child: history.isEmpty ? const Center(child: Text('هنوز جلسه‌ای ثبت نشده', style: TextStyle(color: Colors.white38))) : ListView.builder(itemCount: history.length, itemBuilder: (_,i) { final r = history[history.length-1-i]; final total = r.logs.values.fold<int>(0,(s,v)=>s+v.length); return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)), child: Row(children: [const Icon(Icons.event_note, color: accent), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r.day, style: const TextStyle(fontWeight: FontWeight.bold)), Text('${r.date.day}/${r.date.month}/${r.date.year}', style: const TextStyle(color: Colors.white54))])), Text('$total ست', style: const TextStyle(color: accent))])); }))]));
  Widget _settingsView() => Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SizedBox(height: 10), const Text('تنظیمات', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), const SizedBox(height: 24), Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)), child: const Row(children: [Icon(Icons.phone_android, color: accent), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('ذخیره‌سازی محلی'), SizedBox(height: 4), Text('اطلاعات تمرین فقط روی گوشی ذخیره می‌شود.', style: TextStyle(color: Colors.white54))]))])), const SizedBox(height: 12), Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)), child: const Row(children: [Icon(Icons.offline_bolt, color: accent), SizedBox(width: 12), Text('بدون اینترنت، تبلیغات یا حساب کاربری')]))]));

  void _addDay() async {
    final controller = TextEditingController();
    final value = await showDialog<String>(context: context, builder: (_) => AlertDialog(title: const Text('روز جدید'), content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: 'مثلاً پنجشنبه')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('لغو')), TextButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('افزودن'))]));
    if (value != null && value.isNotEmpty) { setState(() { days.add(WorkoutDay(value, [])); selectedDay = days.length-1; }); await _save(); }
  }
  void _editDayName() async {
    final c = TextEditingController(text: days[selectedDay].name);
    final value = await showDialog<String>(context: context, builder: (_) => AlertDialog(title: const Text('ویرایش نام روز'), content: TextField(controller: c, autofocus: true), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('لغو')), TextButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('ذخیره'))]));
    if (value != null && value.isNotEmpty) { setState(() => days[selectedDay].name = value); await _save(); }
  }
  void _addExercise() => _exerciseDialog();
  void _editExercise(Exercise e) => _exerciseDialog(existing: e);
  Future<void> _exerciseDialog({Exercise? existing}) async {
    final n = TextEditingController(text: existing?.name ?? ''); final s = TextEditingController(text: '${existing?.sets ?? 3}'); final r = TextEditingController(text: '${existing?.reps ?? 10}');
    final result = await showDialog<List<String>>(context: context, builder: (_) => AlertDialog(title: Text(existing == null ? 'حرکت جدید' : 'ویرایش حرکت'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: n, autofocus: true, decoration: const InputDecoration(labelText: 'نام حرکت')), Row(children: [Expanded(child: TextField(controller: s, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ست'))), const SizedBox(width: 12), Expanded(child: TextField(controller: r, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'تکرار')))])]), actions: [if(existing != null) TextButton(onPressed: () => Navigator.pop(context, ['__delete__']), child: const Text('حذف', style: TextStyle(color: Colors.redAccent))), TextButton(onPressed: () => Navigator.pop(context), child: const Text('لغو')), TextButton(onPressed: () => Navigator.pop(context, [n.text.trim(),s.text,r.text]), child: const Text('ذخیره'))]));
    if (result == null) return;
    if (result.first == '__delete__') { setState(() => days[selectedDay].exercises.remove(existing)); await _save(); return; }
    if (result[0].isEmpty) return;
    final ex = Exercise(result[0], int.tryParse(result[1]) ?? 3, int.tryParse(result[2]) ?? 10);
    setState(() { if(existing == null) days[selectedDay].exercises.add(ex); else { existing.name = ex.name; existing.sets = ex.sets; existing.reps = ex.reps; } }); await _save();
  }
  Future<void> _startWorkout() async {
    final day = days[selectedDay]; final logs = <String,List<SetEntry>>{};
    for (final e in day.exercises) logs[e.name] = List.generate(e.sets, (_) => SetEntry(e.reps, 0));
    final result = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => WorkoutSession(day: day.name, exercises: day.exercises, logs: logs)));
    if (result == true) { final rec = ModalRoute.of(context); if(rec != null) {} final workout = SessionRecord(day.name, DateTime.now(), logs); setState(() => history.add(workout)); await _save(); }
  }
}


class WorkoutSession extends StatefulWidget {
  final String day;
  final List<Exercise> exercises;
  final Map<String,List<SetEntry>> logs;
  const WorkoutSession({super.key, required this.day, required this.exercises, required this.logs});
  @override
  State<WorkoutSession> createState() => _WorkoutSessionState();
}
class _WorkoutSessionState extends State<WorkoutSession> {
  int current = 0;
  @override
  Widget build(BuildContext context) {
    final ex = widget.exercises[current]; final entries = widget.logs[ex.name]!;
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(backgroundColor: bg, appBar: AppBar(backgroundColor: bg, title: Text(widget.day), actions: [TextButton(onPressed: _finish, child: const Text('پایان', style: TextStyle(color: accent))) ]), body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('حرکت ${current+1} از ${widget.exercises.length}', style: const TextStyle(color: Colors.white54)), const SizedBox(height: 10), Text(ex.name, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), const SizedBox(height: 22),
      Container(padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15)), child: const Row(children: [Expanded(child: Text('ست', style: TextStyle(color: Colors.white54))), Expanded(child: Text('وزنه (کیلو)', style: TextStyle(color: Colors.white54))), Expanded(child: Text('تکرار', style: TextStyle(color: Colors.white54))), SizedBox(width: 42)])), const SizedBox(height: 8),
      Expanded(child: ListView.builder(itemCount: entries.length, itemBuilder: (_,i) { final item = entries[i]; return Padding(padding: const EdgeInsets.only(bottom: 8), child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14)), child: Row(children: [Expanded(child: Text('${i+1}', style: const TextStyle(fontWeight: FontWeight.bold))), Expanded(child: _numField(item.weight.toStringAsFixed(item.weight % 1 == 0 ? 0 : 1), (v) => item.weight = double.tryParse(v) ?? 0)), Expanded(child: _numField('${item.reps}', (v) => item.reps = int.tryParse(v) ?? 0)), Checkbox(value: false, onChanged: (_) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ست ${i+1} انجام شد'), duration: const Duration(milliseconds: 650))); })]))); })),
      const SizedBox(height: 12), Row(children: [Expanded(child: OutlinedButton(onPressed: current > 0 ? () => setState(() => current--) : null, child: const Text('حرکت قبلی'))), const SizedBox(width: 10), Expanded(child: FilledButton(style: FilledButton.styleFrom(backgroundColor: accent, foregroundColor: bg), onPressed: current < widget.exercises.length-1 ? () => setState(() => current++) : _finish, child: Text(current < widget.exercises.length-1 ? 'حرکت بعدی' : 'پایان تمرین')))]),
    ]))));
  }
  Widget _numField(String value, ValueChanged<String> onChanged) => TextField(key: ValueKey(value + current.toString()), controller: TextEditingController(text: value), keyboardType: const TextInputType.numberWithOptions(decimal: true), textAlign: TextAlign.center, onChanged: onChanged, decoration: const InputDecoration(isDense: true, contentPadding: EdgeInsets.symmetric(vertical: 8), border: OutlineInputBorder()));
  void _finish() { Navigator.pop(context, true); }
}
